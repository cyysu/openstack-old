# flake8: noqa
from keystoneclient.v2_0.client import Client
