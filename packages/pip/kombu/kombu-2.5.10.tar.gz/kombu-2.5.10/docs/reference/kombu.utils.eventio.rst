==========================================================
 Evented I/O - kombu.utils.eventio
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.eventio

.. automodule:: kombu.utils.eventio
    :members:
    :undoc-members:
